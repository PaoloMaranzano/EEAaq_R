## ----setup--------------------------------------------------------------------
library(EEAaq)

## -----------------------------------------------------------------------------
 #Query NO2 data for a specific LAU zone
data_lau<- EEAaq::EEAaq_get_data(
  zone_name = "15146",      # LAU zone code
  NUTS_level = "LAU",       # NUTS level
  LAU_ISO = "IT",           # Country code for Italy
  pollutants = "PM10",       # Pollutant 
  from = "2022-01-01",      # Start date
  to = "2023-12-31",        # End date
  verbose = FALSE            # Print detailed progress
)

## -----------------------------------------------------------------------------
# Preview the first few rows of the dataset
head(data_lau)

## -----------------------------------------------------------------------------
#Identify the names of the areas from which to download the data
zones <- c("Région de Bruxelles-Capitale/Brussels Hoofdstedelijk Gewest","Vlaams Gewest","West-Nederland","Zuid-Nederland")

data <- EEAaq::EEAaq_get_data(
  zone_name = zones,      # LAU zone code
  NUTS_level = "NUTS1",       # NUTS level
  pollutants = c("NO2", "PM10"),       # Pollutant 
  from = "2023-01-01",      # Start date
  to = "2024-08-29",        # End date
  verbose = FALSE            # Print detailed progress
)

## -----------------------------------------------------------------------------
base::unique(data$AirQualityStationEoICode)

## -----------------------------------------------------------------------------
#Map the stations using as EEAaq_df object, the output of the previous function
EEAaq::EEAaq_map_stations(data = data, bounds_level = "NUTS3", color = FALSE, dynamic = FALSE)




## -----------------------------------------------------------------------------
EEAaq::EEAaq_map_stations(zone_name = zones, NUTS_level = "NUTS1",
pollutant = c("NO2", "PM10"), bounds_level = "NUTS3", color = FALSE, dynamic = FALSE)

## -----------------------------------------------------------------------------
EEAaq::EEAaq_map_stations(data =data_lau, color =
TRUE, dynamic=TRUE, ID= TRUE )


## -----------------------------------------------------------------------------
summ <- EEAaq::EEAaq_summary(data = data)

## -----------------------------------------------------------------------------
summ$Summary

## -----------------------------------------------------------------------------
summ$Summary_byStat$Mean_byStat

## -----------------------------------------------------------------------------
summ$Corr_Matrix

## -----------------------------------------------------------------------------
#Get the monthly minimum, maximum, mean and median values of the pollutant concentrations
t_aggr <- EEAaq::EEAaq_time_aggregate(data = data, frequency =
"monthly", aggr_fun = c("min", "max", "mean", "median" ))


## -----------------------------------------------------------------------------
t_aggr$TimeAggr

## -----------------------------------------------------------------------------
t_aggr$TimeAggr_byPollutant$PM10

## -----------------------------------------------------------------------------
EEAaq::EEAaq_idw_map(data = t_aggr, pollutant = "NO2", aggr_fun =
"mean", distinct = TRUE, gradient = TRUE, idp = 2)

## -----------------------------------------------------------------------------
t_aggr_1 <- EEAaq::EEAaq_time_aggregate(data = data_lau, frequency =
"monthly", aggr_fun = c("min", "max", "mean", "median" ))
EEAaq::EEAaq_idw_map(data = t_aggr_1, pollutant = "NO2", aggr_fun = "mean",
   distinct = TRUE, gradient = FALSE, dynamic = TRUE, fill_NUTS_level = "LAU")

