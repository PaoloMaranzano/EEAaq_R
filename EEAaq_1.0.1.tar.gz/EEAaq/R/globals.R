utils::globalVariables(c("Code", "CITY_ID", "CITY_NAME", "nuts", "geometry", "LAU_ID", "coor", ".data", "Var1", "Var2","."))
`%within%` <- lubridate::`%within%`
